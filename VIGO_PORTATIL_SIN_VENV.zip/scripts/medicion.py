import Meas_classes as ms
import paramiko
import json, time
import numpy as np
import pandas as pd

# ── PARÁMETROS ────────────────────────────────────────────────────────
PROTECT     = 0.0011
VOLTAJES    = np.linspace(1, 3, 5)
INPORT      = 21
N_RETOS     = 2

# ── 1. CONECTAR KEITHLEY (una sola vez) ─────────────────────────────────
keithley = ms.Keithley('20', 'GPIB0', 0.0011, -3)
keithley.set_keithley_for_meas_current()
keithley.on_keithley_fixed_volt()

# ── 2. CONECTAR SSH AL SMARTLIGHT (una sola vez) ────────────────────────
ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect('10.42.0.125', username='smartlight', password='29c6b8177fdf9b4523e93474d04a0ffa')

stdin, stdout, stderr = ssh.exec_command(
    'cd /home/smartlight/Oxel/VIGO && python3 medir_loop.py'
)

def medir_remoto(inport, n_retos):
    cmd = {'inport': inport, 'n_retos': n_retos}
    stdin.write(json.dumps(cmd) + '\n')
    stdin.flush()
    return json.loads(stdout.readline())

# ── 3. BARRIDO DE VOLTAJE + MEDIDA DEL CHIP ─────────────────────────────
resultados = []

for v in VOLTAJES:
    keithley.volt_source = v
    keithley.on_keithley_fixed_volt()
    time.sleep(0.3)

    V_medido, I_medido = keithley.read_keithley()
    res_chip = medir_remoto(inport=INPORT, n_retos=N_RETOS)

    if 'error' in res_chip:
        print(f'⚠ V={v:.2f} V → error SmartLight: {res_chip["error"]}')
        continue

    resultados.append({
        'voltaje_programado': v,
        'voltaje_medido':     V_medido,
        'corriente_mA':       I_medido,
        'powers':             res_chip['powers'],
    })

    print(f'V={v:.2f} V  →  V_medido={V_medido:.4f} V,  '
          f'I={I_medido:.4f} mA,  {res_chip["n_medidos"]} retos medidos')

# ── 4. CIERRE LIMPIO ─────────────────────────────────────────────────
keithley.off_keithley_volt()

stdin.write('EXIT\n')
stdin.flush()
ssh.close()

# ── 5. GUARDAR RESULTADOS ────────────────────────────────────────────
with open('barrido_voltaje_chip.json', 'w') as f:
    json.dump(resultados, f, indent=2)

df_resumen = pd.DataFrame([
    {'voltaje_programado': r['voltaje_programado'],
     'voltaje_medido':     r['voltaje_medido'],
     'corriente_mA':       r['corriente_mA'],
     'n_retos':            len(r['powers'])}
    for r in resultados
])
df_resumen.to_csv('barrido_voltaje_resumen.csv', index=False)

print(f'\n✓ {len(resultados)} puntos guardados en barrido_voltaje_chip.json')
print(df_resumen)