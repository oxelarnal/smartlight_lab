import sys
import pyvisa
import numpy as np
import pandas as pd

def verificar_entorno():
    print("--- Verificación de Entorno Vigo ---")
    # 1. Comprobar Python
    print(f"Python ejecutable: {sys.executable}")
    
    # 2. Comprobar Librerías
    try:
        rm = pyvisa.ResourceManager()
        print(f"PyVISA instalado correctamente. Backend: {rm.visalib}")
        print("Librerías científicas (NumPy/Pandas) listas.")
        print("\n¡Todo está listo para ir a Vigo!")
    except Exception as e:
        print(f"Error detectado: {e}")

if __name__ == "__main__":
    verificar_entorno()