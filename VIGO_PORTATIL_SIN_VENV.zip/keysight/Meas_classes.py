import time
import numpy as np
import matplotlib.pyplot as plt
import pyvisa as visa
import sys
 
class Keithley(object):

    """
    Modelling of a Keithley source
    :param gpib_id: GPIB ID of the laser to establish the connection.
    :param gpib_address: GPIB address of the laser to establish the connection.
    :param protection_current: Protection current (mA)
    :param volt_source: Fixed voltage source (V)
    """

    def __init__(self, gpib_id: str, gpib_address: str, protection_current: float, volt_source: float) -> None:

        rm = visa.ResourceManager()
        print(rm.list_resources())
        self.gpib_id = gpib_id
        self.gpib_address = gpib_address
        self.protection_current = protection_current
        self.volt_source = volt_source
        self.keithley = rm.open_resource(str(self.gpib_address) + '::' + str(self.gpib_id) + '::INSTR')
        print(self.keithley.query('*IDN?'))

    def set_keithley_for_meas_current(self): 

        """        
        Voltage source and current measurement
        """
        self.keithley.write(":SOUR:FUNC VOLT") 
        self.keithley.write(":SOUR:CURR:MODE FIX") #Fixed mode
        self.keithley.write(":SOUR:VOLT:RANGE:AUTO 1") #Fixed mode
        self.keithley.write(':SENS:FUNC "'+'CURR'+'"')
        self.keithley.write(":SENS:CURR:PROT:LEV " + str(self.protection_current)) #maxima corriente entregada
        self.keithley.write(":SENS:CURR:DC:RANG:AUTO 1") #rango de la reslucion de la medida de corriente
        self.keithley.write(":SOUR:VOLT:LEV "+str(float(0)))
        self.keithley.write(":OUTP:STAT OFF")
        return

    def on_keithley_fixed_volt(self):
        self.keithley.write(":OUTP:STAT ON")
        self.keithley.write(":SOUR:VOLT:LEV "+str(float(self.volt_source)))
        return

    def off_keithley_volt(self):
        self.keithley.write(":SOUR:VOLT:LEV "+str(float(0)))
        self.keithley.write(":OUTP:STAT OFF")
        return    

    def read_keithley(self):
        V = float(self.keithley.query(":READ?").split(",")[0])
        I = 1e3*float(self.keithley.query(":READ?").split(",")[1])
        return V,I

class Laser_TL17(object):

    """
    Modelling of TL17 laser source
    :param gpib_id: GPIB ID of the laser to establish the connection.
    :param gpib_address: GPIB address of the laser to establish the connection.
    :param power: Fixes the optical output power of the laser (dBm).
    :param wl: Fixes the wavelength of the laser (nm).
    """

    def __init__(self, gpib_id: int, gpib_address: int, power: float, wl: float) -> None:

        rm = visa.ResourceManager()
        print(rm.list_resources())
        self.gpib_id = gpib_id
        self.gpib_address = gpib_address
        self.power = power
        self.wl = wl
        self.laser = rm.open_resource(str(self.gpib_address) + '::' + str(self.gpib_id) + '::INSTR')
        self.laser.read_termination = '\n'
        print(self.laser.query('*IDN?'))

    def set_power_laser(self): 
        self.laser.write("DBM")                    #Set the units of the laser at dBm
        self.laser.write("P="+str(self.power))     #Set the input optical power
        return

    def set_wl_laser(self): 
        self.laser.write("L="+str(self.wl))
        return

    def on_laser(self):
        self.laser.write("ENABLE") 
        return
    def off_laser(self):
        self.laser.write("DISABLE") 
        return  
 
class Yokogawa(object):

    """
    Modelling of OSA Yokogawa 
    :param gpib_id: GPIB ID of the laser to establish the connection.
    :param gpib_address: GPIB address of the laser to establish the connection.
    :param wvl_init: Fixes the initial wavelength.
    :param wvl_end: Fixes the final wavelength.
    :param wvl_resol: Fixes the wavelength resolution.
    :param num_points: Fixes the number of points in the wlv array.
    """
    
    def __init__(self, gpib_id: int, gpib_address: int, wvl_init: float, wvl_end: float, wvl_resol: float, num_points: float,) -> None:
    
        rm = visa.ResourceManager()
        print(rm.list_resources())
        self.gpib_id = gpib_id
        self.gpib_address = gpib_address
        self.wvl_init = wvl_init
        self.wvl_end = wvl_end
        self.wvl_resol = wvl_resol
        self.num_points = num_points
        self.osa = rm.open_resource(str(self.gpib_address) + '::' + str(self.gpib_id) + '::INSTR')
        print(self.osa.query('*IDN?'))
    
    def osa_meas_configuration(self,):
        self.osa.write("FORMAT:DATA ASCII")
        time.sleep(1)
        self.osa.write(":SENSE:BANDWIDTH:RESOLUTION "+str(self.wvl_resol)+"NM")
        self.osa.write(":SENSE:WAVELENGTH:STAR "+str(self.wvl_init)+"NM")
        self.osa.write(":SENSE:WAVELENGTH:STOP "+str(self.wvl_end)+"NM")
        self.osa.write(":SENSE:SWEEP:POINTS "+str(self.num_points))
        time.sleep(1)
        return
        
    def osa_meas_single(self,):
        time.sleep(2)
        self.osa.write(":INITIATE:SMODE SINGLE")  # OSA sweep single

        self.osa.write("*CLS")  # OSA clear status
        self.osa.write(":INITIATE")  # Inicia barrido OSA

        self.osa.write(":TRACE:X? TR"+str('A'))  # Lee la longitud de onda de la traza A
        wvl = (self.osa.read().split(","))  # read the data
        array_wvl = np.array(wvl, dtype=float)
        array_wvl = array_wvl*1e9 #nm
        
        self.osa.write(":TRACE:Y? TR"+'A')  # Lee la potencia de la traza A
        list_power = self.osa.read().split(",")  # read the data
        array_power = np.array(list_power, dtype=float)

        return array_wvl, array_power
    













