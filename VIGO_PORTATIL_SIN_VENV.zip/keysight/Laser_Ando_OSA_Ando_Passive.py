import sys
from math import *
import pyvisa as visa   # import the library to be able to read the equipment on the GPIB bus
import time				# import the library to make the timedelay to wait for movement of the stages
import matplotlib.pyplot as plt
import os.path
import numpy as np
#============================================================================
rm = visa.ResourceManager()
print(rm.list_resources())

#DEVICES

osa = rm.open_resource('GPIB0::2::INSTR')

##-----------------------------------------
#
print(osa.query('*IDN?'))

osa.write("FORMAT:DATA ASCII")
osa.timeout = 20000000 #Esperammos respuestas


#### folder & name
name_site_file='C:/Users/Pablo/Desktop/Medidas/TBU_iPronics/'
dut_name = 'Setup_17_11_2021';
filename = name_site_file + dut_name 
trazas=['A','B','C']
tt=0

time.sleep(2)


##WAVELENGTH DEFINITION
wvl_init=1520
wvl_end=1600
wvl_resol=2.00
num_sampl=1001;
#---------------------

osa.write("TLSADR14")
osa.write("TLSSYNC1")
print(osa.query("TLSADR?"))
print(osa.query("TLSSYNC?"))


osa.write("RESLN"+str(wvl_resol))
osa.write("STAWL"+str(wvl_init))
osa.write("STPWL"+str(wvl_end))
osa.write("SMPL"+str(num_sampl))

osa.write("WRTA")
osa.write("ACTV0")
 

osa.write("SGL")

while int(osa.query("SWEEP?")) != 0:
    time.sleep(10)
        
print('Sweep end') 
  
osa.write("WDAT"+str(trazas[tt]))
wvl=(osa.read().split(",")) #read the data
array_wvl = np.array(wvl, dtype=float)

osa.write("LDAT"+trazas[tt])
list_power=osa.read().split(",") #read the data
array_power = np.array(list_power, dtype=float)

    #save raw data
f = open(filename+".txt",'w')
   
for iii in range(0,len(array_power),1):
    write_string = "%3.9f \t %3.9f\n" % (float(array_wvl[iii]), array_power[iii])
    f.write(write_string)
f.close()

