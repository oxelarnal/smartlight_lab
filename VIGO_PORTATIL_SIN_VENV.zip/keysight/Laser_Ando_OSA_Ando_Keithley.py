import sys
from math import *
import pyvisa as visa             # import the library to be able to read the equipment on the GPIB bus
import time				# import the library to make the timedelay to wait for movement of the stages
import matplotlib.pyplot as plt
import os.path
import numpy as np
#============================================================================
rm = visa.ResourceManager()
print(rm.list_resources())

#DEVICES
osa = rm.open_resource('GPIB0::2::INSTR')
keithley = rm.open_resource("GPIB0::28::INSTR") 

#-----------------------------------------

print(osa.query('*IDN?'))
print(keithley.query('*IDN?'))


osa.timeout = 20000000

#### folder & name
name_site_file='C:/Users/mmang/UPV/Lab_PRL - General/Medidas_TBU_iPronics/TBU_3_1/'
dut_name = 'TBU_3_1_Bar';
filename = name_site_file + dut_name 
trazas=['A','B','C']
tt=0

#Fuente corriente - medida tension
keithley.write(":SOUR:FUNC CURR") 
keithley.write(":SOUR:VOLT:MODE FIX") #Fixed mode
keithley.write(":SOUR:CURR:RANGE:AUTO 1") #Fixed mode
keithley.write(':SENS:FUNC "'+'VOLT'+'"')
keithley.write(":SENS:VOLT:PROT:LEV 21") #maxima corriente entregada
keithley.write(":SENS:VOLT:DC:RANG:AUTO 1") #rango de la reslucion de la medida de corriente

time.sleep(2)

###Intensity definition                          #Numero de puntos de intensidad totales
Imin = 0                              #Miliamperios
Imax = 4
I=np.array(np.arange(0,4,0.05)) #Miliamperios
array_I = np.array(I, dtype=float)


keithley.write(":OUTP:STAT ON")
k_v=[]
k_i=[]


##Wavelength definition
wvl_init=1540
wvl_end=1560
wvl_resol=2.00
num_sampl=50

#-----------------------------------------

#print(osa.query("TLSADR?"))
#print(osa.query("TLSSYNC?"))
osa.write("TLSADR14")
osa.write("TLSSYNC1")

osa.write("RESLN"+str(wvl_resol))
#print(osa.query("RESLN?"))
osa.write("STAWL"+str(wvl_init))
osa.write("STPWL"+str(wvl_end))
osa.write("SMPL"+str(num_sampl))

osa.write("WRTA")
osa.write("ACTV0")

a = 1

for ii in range(0,len(array_I),1):
    keithley.write(":SOUR:CURR:LEV "+str(float(array_I[ii])*1e-3))
    time.sleep(0.1)  
    V= 1e3*float(keithley.query(":READ?").split(",")[0])
    I= 1e3*float(keithley.query(":READ?").split(",")[1])
    k_i.append(I)
    k_v.append(V)
    osa.write("SGL")

    while int(osa.query("SWEEP?")) != 0:
        time.sleep(3)
            
    print('Sweep ',I,'mA end') 
  
    osa.write("WDAT"+str(trazas[tt]))
    wvl=(osa.read().split(",")) #read the data
    array_wvl = np.array(wvl, dtype=float)
    
    osa.write("LDAT"+trazas[tt])
    list_power=osa.read().split(",") #read the data
    array_power = np.array(list_power, dtype=float)

    #save raw data
    f = open(filename +"_I_mA_"+str(a)+str(str(float(round(I,1)))+"_mV_"+str(k_v[ii]))  +".txt",'w')
   
    
    for iii in range(0,len(array_power),1):
        write_string = "%3.9f \t %3.9f\n" % (float(array_wvl[iii]), array_power[iii])
        f.write(write_string)
    f.close()
    keithley.write(":SOUR:CURR:LEV "+str(float(0)*1e-3))
    a = a+1
    
f = open(filename +'Intensidades' +".txt",'w')
for iii in range(0,len(k_i),1):
                write_string = "%3.9f\n" % (float(k_i[iii]))
                f.write(write_string)
f.close()  

f = open(filename +'Volt' +".txt",'w')
for iii in range(0,len(k_v),1):
                write_string = "%3.9f\n" % (float(k_v[iii]))
                f.write(write_string)
f.close()         