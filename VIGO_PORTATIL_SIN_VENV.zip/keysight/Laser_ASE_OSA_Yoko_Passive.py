import sys
from math import *
import visa             # import the library to be able to read the equipment on the GPIB bus
import time				# import the library to make the timedelay to wait for movement of the stages
import matplotlib.pyplot as plt
import os.path
import numpy as np
#============================================================================
rm = visa.ResourceManager()
print(rm.list_resources())

#DEVICES
osa = rm.open_resource('GPIB1::1::INSTR')

##-----------------------------------------

print(osa.query('*IDN?'))
osa.timeout = 20000000
osa.write("FORMAT:DATA ASCII")

##Folder & Name
# name_site_file='C:/Users/ERC 2/Dropbox/UMWP-CHIP TECHNICAL/WORKPACKAGES/WP1/ERC_Design/ERCDESIGN_AFM2021/Measurements/UPV_Run_001_Passive_Wafers/D3_S/PUCs/'

# dut_name = 'Setup_Isolator_&_Splitter_CROSS';
# filename = name_site_file + dut_name #testprop_0
trazas=['A','B','C']

tt=0

time.sleep(2)

##Wavelength definition
wvl_init=1520
wvl_end=1580
wvl_resol=2

#-----------------------------------------

osa.write("SENSE:BANDWIDTH:RESOLUTION "+str(wvl_resol)+"NM")
osa.write(":SENSE:WAVELENGTH:STAR "+str(wvl_init)+"NM")
osa.write(":SENSE:WAVELENGTH:STOP "+str(wvl_end)+"NM")

osa.write(":INITIATE:SMODE SINGLE")

osa.write(":TRACE:X? TR"+str(trazas[tt]))
wvl=(osa.read().split(",")) #read the data
array_wvl = np.array(wvl, dtype=float)
array_wvl = array_wvl*1e9

osa.write(":TRACE:Y? TR"+trazas[tt])
list_power=osa.read().split(",") #read the data
array_power = np.array(list_power, dtype=float)

#Save raw data
# f = open(filename +".txt",'w')
    
# for iii in range(0,len(array_power),1):
#     write_string = "%3.9f \t %3.9f\n" % (float(array_wvl[iii]), array_power[iii])
#     f.write(write_string)
# f.close()
