# -*- coding: utf-8 -*-
"""
Created on Thu Dec 11 15:22:39 2025

@author: Dani
"""

import Meas_classes as ms
import numpy as np
import time
import pandas as pd
import matplotlib.pyplot as plt

protect = 0.001
volt1 = 3
volt2 = 3
wl = 1550
power = 1



keithley = ms.Keithley('24','GPIB1',0.001,3)
keithley2 = ms.Keithley('20','GPIB1',0.0011,-3)
keithley3 = ms.Keithley('28','GPIB1',0.0012,0)
laser = ms.Laser_TL17('10', 'GPIB1',power,wl)


keithley.set_keithley_for_meas_current()
keithley2.set_keithley_for_meas_current()
keithley3.set_keithley_for_meas_current()

laser.set_wl_laser()
laser.set_power_laser()

#%%
wavelength_list = np.linspace(1549,1550,300)
I_list=[]
I2_list=[]
I_dif_list=[]

laser.on_laser()

keithley.on_keithley_fixed_volt()
keithley2.on_keithley_fixed_volt()
keithley3.on_keithley_fixed_volt()
for i in range(len(wavelength_list)):
    laser.wl = wavelength_list[i]
    laser.set_wl_laser()
    time.sleep(0.1)
    V,I = keithley.read_keithley()
    V2,I2 = keithley2.read_keithley()
    V3,I3 = keithley3.read_keithley()
    time.sleep(0.1)
    
    I_list.append(I)
    I2_list.append(I2)
    I_dif_list.append(I3)

keithley.off_keithley_volt()
keithley2.off_keithley_volt()
keithley3.off_keithley_volt()
laser.off_laser()
#%%
I_list=np.array(I_list)
I2_list=np.array(I2_list)
I_dif_list=np.array(I_dif_list)



plt.figure()
plt.plot(wavelength_list,I_list)
plt.plot(wavelength_list,-I2_list)
plt.plot(wavelength_list,I_dif_list)
plt.plot(wavelength_list,-(I_list+I2_list))
plt.show()


#%%

directory = r"C:\Users\Dani\Desktop\Medida_hibrido_AMF"
filename = 'first_photodiode'

data = {"Wavelength" : np.array(wavelength_list), "Current": np.array(I_list)}
dataframe = pd.DataFrame(data)
dataframe.to_csv(directory + "/" + filename + '.csv')




