try:
    import numpy as np
    import matplotlib.pyplot as plt
    import time as tic
    import qontrol
    import sys
    # import the library to be able to read the equipment on the GPIB bus
    import pyvisa as visa
    import time				# import the library to make the timedelay to wait for movement of the stages
    import matplotlib.pyplot as plt
    import os.path
    import numpy as np
    print("All packages have been loaded correctly")
except:
    print("Some packages could not been loaded")

def Lectura_YOKO_ramzi(wvl_init, wvl_end, wvl_resol, num_points, fshift):

    rm = visa.ResourceManager()
    # print(rm.list_resources())
    # DEVICES
    osa = rm.open_resource('GPIB0::1::INSTR')
    # -----------------------------------------
    # print(osa.query('*IDN?'))
    osa.timeout = 2000000000
    osa.write("FORMAT:DATA ASCII")

    trazas = ['A', 'B', 'C']
    tt = 0
    time.sleep(2)

    osa.write(":SENSE:BANDWIDTH:RESOLUTION "+str(wvl_resol)+"NM")
    osa.write(":SENSE:WAVELENGTH:STAR "+str(wvl_init)+"NM")
    osa.write(":SENSE:WAVELENGTH:STOP "+str(wvl_end)+"NM")
    osa.write(":SENSE:SWEEP:POINTS "+str(num_points))

    # -----------------------------------------------

    osa.write(":INITIATE:SMODE SINGLE")  # OSA sweep single
    osa.write("*CLS")  # OSA clear status
    osa.write(":INITIATE")  # Inicia barrido OSA

    osa.write(":TRACE:X? TR"+str(trazas[tt]))  # Lee la longitud de onda
    wvl = (osa.read().split(","))  # read the data
    array_wvl = np.array(wvl, dtype=float)
    array_wvl = array_wvl*1e9
    
    osa.write(":TRACE:Y? TR"+trazas[tt])  # Lee la potencia
    list_power = osa.read().split(",")  # read the data
    array_power = np.array(list_power, dtype=float)
    norm_power = array_power-max(array_power)
    max_opower = max(array_power)

    plt.plot(array_wvl,array_power,linewidth=0.8)
    # plt.ylim(-15, 0)
    plt.title(str(max_opower))
    plt.xlabel("Wavelength (nm)", fontsize = 12)
    plt.ylabel("Normalized Optic Power (dB)", fontsize = 12)
    plt.show()
    
    # fou = np.fft.fft(norm_power)
    
    # Fou_norm = abs(fou)/max(abs(fou))
    
    # K = array_wvl**(2)*fshift/(4.18*L)
    # FSR = 1/fshift
        
    # plt.plot(K, Fou_norm, 'red')  
    # plt.xlim(0, zoom)
    # plt.ylim(0, 0.3)
    # # plt.text(zoom-0.26, .24, r"U = 1.25 nm", color="b", fontsize=10)
    # # plt.text(zoom-0.26, .225, r"2U = 0.63 nm", color="b", fontsize=10)
    # # plt.text(zoom-0.26, .21, r"3U = 0.42 nm", color="b", fontsize=10)
    # # plt.text(zoom-0.26, .195, r"4U = 0.31 nm", color="b", fontsize=10)
    # # plt.text(zoom-0.26, .18, r"5U = 0.25 nm", color="b", fontsize=10)
    # # plt.text(zoom-0.26, .165, r"6U = 0.21  nm", color="b", fontsize=10)    
    # # plt.text(zoom-0.26, .15, r"7U = 0.18 nm", color="b", fontsize=10)
    # # plt.text(zoom-0.26, .13, r"16U = 0.55 nm", color="b", fontsize=10)
    # # plt.text(0.15, .225, str(intensity), color="b", fontsize=10)
    # # plt.text(0.15, .210, str(intensity*voltaje), color="r", fontsize=10)
    # # plt.text(0.15, .195, str(max_opower), color="g", fontsize=10)
    # plt.xlabel("Bit Configuration", fontsize = 12)
    # plt.ylabel("FFT Intensity (a.u) ", fontsize = 12)
    # plt.show()
    
    # limx = 1.3 
    
    # plt.plot(FSR, Fou_norm, 'green') 
    # plt.text(limx-0.26, .24, r"U = 1.25 nm", color="b", fontsize=10)
    # plt.text(limx-0.26, .225, r"2U = 0.63 nm", color="b", fontsize=10)
    # plt.text(limx-0.26, .21, r"3U = 0.42 nm", color="b", fontsize=10)
    # plt.text(limx-0.26, .195, r"4U = 0.31 nm", color="b", fontsize=10)
    # plt.text(limx-0.26, .18, r"5U = 0.25 nm", color="b", fontsize=10)
    # plt.text(limx-0.26, .165, r"6U = 0.21  nm", color="b", fontsize=10)    
    # plt.text(limx-0.26, .15, r"7U = 0.18 nm", color="b", fontsize=10)
    # plt.text(limx-0.26, .13, r"16U = 0.55 nm", color="b", fontsize=10)
    # plt.text(limx-0.26, .24, r"U = 1.102 nm", color="b", fontsize=10)
    # plt.text(limx-0.26, .225, r"2U = 0.55 nm", color="b", fontsize=10)
    # plt.text(limx-0.26, .21, r"3U = 0.37 nm", color="b", fontsize=10)
    # plt.text(limx-0.26, .195, r"4U = 0.28 nm", color="b", fontsize=10)
    # plt.text(limx-0.26, .18, r"5U = 0.22 nm", color="b", fontsize=10)
    # plt.text(limx-0.26, .165, r"6U = 0.18 nm", color="b", fontsize=10)    
    # plt.text(limx-0.26, .15, r"7U = 0.16 nm", color="b", fontsize=10)
    # plt.xlim(0, 1)
    # plt.ylim(0, 0.3)
    # plt.ylabel("FFT Intensity (a.u) ", fontsize = 12)
    # plt.xlabel("FSR (nm)", fontsize = 12)
    # plt.show()

    return