import sys
import sys
from math import *
import visa             # import the library to be able to read the equipment on the GPIB bus
import time				# import the library to make the timedelay to wait for movement of the stages
import matplotlib.pyplot as plt
import os.path
import numpy as np
import pyvisa as visa
from matplotlib.ticker import StrMethodFormatter


rm = visa.ResourceManager()
print(rm.list_resources())

#LTB-1 data for keysight connection expert:
    # Hostname or IP address: 169.254.201.139
    #TCPIP Interface ID: TCPIP0
    #Socket --> Port Number: 5025
    #Allow *IDN Query
    
# DEVICES
pm= rm.open_resource("TCPIP0::192.168.0.1::5025::SOCKET")
pm.read_termination = '\n'
pm.write_termination = '\n'
print(pm.query('*IDN?'))

laser = rm.open_resource('GPIB1::1::INSTR')
laser.read_termination = '\n'
print(laser.query('*IDN?'))
laser.write('ENABLE')


# FOLDER & NAME
name_site_file='C:/Users/ercum/Dropbox/UMWP-CHIP TECHNICAL/WORKPACKAGES/WP1/ERC_Design/ERCDESIGN_AFM2021/Measurements/AMF_CITC_CHIP_Reflections_Study/Laser_TL17_PM_EXFO/'
dut_name = 'UPUC34_1pm_10s'
filename = name_site_file + dut_name 


# LASER CONFIGURATION
input_power=0;
wv_ini=1549.900;
wv_fin=1550.100;
# wv_step=0.001;
points_number=200;
wv_step=(wv_fin-wv_ini)/points_number;
wv=np.array(np.arange(wv_ini,wv_fin+wv_step,wv_step))   #Wavelength array
array_wv=np.array(wv,dtype=float)
laser.write("DBM")                              #Set the units of the laser at dBm
laser.write("P="+str(input_power))             #Set the input optical power
laser.write("ENABLE")                           #Turns optical output On

# POWER METER CONFIGURATION
channel_number=1
pm.write('LINS0:UNIT'+str(channel_number)+':POW DBM')   #Set the units of the power meter at dBm
array_pw=[]                                             #To keep the powers

time.sleep(2)
laser.write("L="+str(wv_ini))
time.sleep(2)

time_ini=time.time()
# LOOP TO OBTAIN THE TRACE
for ii in range(0,len(array_wv),1):

    # Set wavelength in the laser
    laser.write("L="+str(array_wv[ii]))
    time.sleep(10)
    
    #Measure power in the power meter
    pw=pm.query('LINS0:READ'+str(channel_number)+':POW:DC?')
    array_pw.append(pw)
    
f = open(filename +".txt",'w')
for iii in range(0,len(array_wv),1):
    write_string = "%3.6f \t %3.6f\n" % (float(array_wv[iii]), float(array_pw[iii]))
    f.write(write_string)
f.close()

# laser.write("L0")                               #Turns optical output Off
time_fin=time.time()
total_time=round((time_fin-time_ini)/60,2);
print('El tiempo de ejecucion es: '+ str(float(total_time)) + 'min')

laser.write("L=1550.000")

plt.grid()
array_pw1 = np.array(array_pw)
array_pw_def = array_pw1.astype(float)
plt.plot(array_wv*1e-3,array_pw_def, color="blue", linewidth=2.5, linestyle="-")
plt.xlabel('Wavelength [nm]')
plt.ylabel('Output Power [dBm]')
plt.show()
print('La potencia maxima es: '+str(float(max(array_pw_def))) + 'dBm')
    
